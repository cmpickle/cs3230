

public class SeasonTile extends PictureTile {
	private static final long serialVersionUID = 1L;

	public SeasonTile(String name) {
		super(name);
	}
}
