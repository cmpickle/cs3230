public class FlowerTile extends PictureTile {
	private static final long serialVersionUID = 1L;

	public FlowerTile(String name) {
		super(name);
	}
}
