public class Bamboo1Tile extends PictureTile {
	private static final long serialVersionUID = 1L;

	public Bamboo1Tile() {
		super("Sparrow");
	}

	public String toString() {
		return "Bamboo 1";
	}
}
