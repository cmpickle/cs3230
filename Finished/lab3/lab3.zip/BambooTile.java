public class BambooTile extends RankTile {
	public BambooTile(int rank) {
		super(rank);
	}
	
	public String toString() {
		return "Bamboo " + rank;
	}
}
