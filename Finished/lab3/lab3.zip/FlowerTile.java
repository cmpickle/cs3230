public class FlowerTile extends PictureTile {
	public FlowerTile(String name) {
		super(name);
	}
}
