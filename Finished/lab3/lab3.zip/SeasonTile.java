public class SeasonTile extends PictureTile {
	public SeasonTile(String name) {
		super(name);
	}
}
